<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dataset = [
            ['name' => '山田太郎'],
            ['name' => '鈴木花子'],
            ['name' => '吉田良夫'],
            ['name' => '田中哲治'],
            ['name' => '杉山吾郎'],
                   
        ];

        foreach ($dataset as $data) {
            \App\Models\Customer::create($data);
        }
    }
}
