@extends('layouts.app')

@section('content')

<h1>顧客情報詳細</h1>

<dl>
    <dt>顧客名</dt>
    <dd>{{ $customer->name }}</dd>
</dl>
<a href="{{ route('customers.edit', $customer) }}">編集</a>
｜
<a href="" onclick="deleteData()">削除</a>
@include('commons.delete', ['_route' => 'customers.destroy', '_model' => $customer])
<hr>
<h2>注文履歴</h2>
<p><a class="btn btn-success" href="{{ route('orders.create', ['customer_id' => $customer->id]) }}">新規注文</a></p>
@include('commons.orders')
@endsection
