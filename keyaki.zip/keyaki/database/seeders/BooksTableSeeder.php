<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Faker\Factory;
use App\Models\Book;

class BooksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 出力件数を指定
        $NUM_FAKER = 50;
        // Factoryインスタンスを生成
        $faker = Factory::create('ja_JP');
        // 本のタイトルのみ英語名なので日本語で定義
        $bookTitles = [
            '気づけばプロ並みPHP',
            '独習PHP',
            'よくわかるPHPの教科書',
            'PHP2024年1月号人生、笑うが勝ち!',
            'レベルアップPHP',
            'PHPふりがなプログラミング',
            '基礎からのMySQL',
            '詳解MySQL Database入門',
            '15時間でわかるMySQL集中講座',
            '3ステップでしっかり学ぶMySQL入門',
            'MySQL徹底入門',
            'Web開発のためのMySQL超入門',
            'PHPフレームワークLaravel入門',
            'PHPフレームワークLaravel実践開発',
            'Laravel速習シリーズ',
            'PHPフレームワークLaravelWebアプリケーション開発',
            'Laravelエキスパート養成読本'
        ];
        $publishers = [
            '集英社',
            'KADOKAWA',
            '小学館',
            '岩波書店',
            '講談社',
            '新潮社',
            '筑摩書房',
            '平凡社',
            '光文社',
            '中央公論社',
            '朝日新聞社',
            'みすず書房',
            '学研ホールディングス',
            'インプレスホールディングス'
        ];
        for ($i = 0; $i < $NUM_FAKER; $i++) {
            Book::create([
                'user_id'    => mt_rand(1, 10),
                'title'      => $bookTitles[mt_rand(0, array_key_last($bookTitles))],
                'author'     => $faker->name(),
                'publisher'  => $publishers[mt_rand(0, array_key_last($publishers))],
                'created_at' => $faker->dateTimeBetween('-3 years', 'now'),
                'updated_at' => $faker->dateTime('now'),
            ]);
        }
    }
}
