<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory;
use App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 人数を指定
        $NUM_FAKER = 10;
        // Factoryインスタンスを生成
        $faker = Factory::create('ja_JP');

        for ($i = 0; $i < $NUM_FAKER; $i++) {
            User::create([
                'name' => $faker->name(),
                'email' => $faker->email(),
                'password' => $faker->password(),
                'updated_at' => $faker->dateTime('now'),
            ]);
        }
    }
}
