@extends('layouts.app')

@section('content')
<h1>お気に入り</h1>
@include('commons.books')
@endsection
