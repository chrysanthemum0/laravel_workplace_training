<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LikeController extends Controller
{
    //お気に入り書籍の一覧のデータ취득
    public function index(){
        $books = \Auth::user()->likeBooks()
                ->orderBy('created_at', 'desc')->paginate(20);
        return view('likes.index', ['books' => $books]);
    }

    //お気に入りを登録する
    public function store(Request $request){
        \Auth::user()->likeBooks()->attach($request->book_id);
        return back();
    }

    //お気に入りを削除する
    public function destroy(Request $request){
        \Auth::user()->likeBooks()->detach($request->book_id);
        return back();
    }
}
