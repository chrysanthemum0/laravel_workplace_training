<?php $__env->startSection('content'); ?>
<h1>マイページ</h1>
<p><a href="<?php echo e(route('books.create')); ?>">＋書籍登録</a></p>
<?php echo $__env->make('commons.books', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/home/index.blade.php ENDPATH**/ ?>