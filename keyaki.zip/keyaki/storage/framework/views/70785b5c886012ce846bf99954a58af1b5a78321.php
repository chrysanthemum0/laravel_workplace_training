<?php $__env->startSection('content'); ?>

<h1>書籍情報</h1>
<p>
    <a href="<?php echo e(route('books.edit', $book)); ?>">編集する</a>
    |
    <a href="#" onclick="deleteBook()">削除する</a>
    <form action="<?php echo e(route('books.destroy', $book)); ?>" method="post" id="delete-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
    </form>
    <script type="text/javascript">
        function deleteBook() {
            event.preventDefault();
            if(window.confirm('本当に削除しますか？')){
                document.getElementById('delete-form').submit();
            }
        }
    </script>
</p>
<dl>
    <dt>タイトル</dt>
    <dd><?php echo e($book->title); ?></dd>
    <dt>著者</dt>
    <dd><?php echo e($book->author); ?></dd>
    <dt>出版社</dt>
    <dd><?php echo e($book->publisher); ?></dd>
    <dt>投稿者</dt>
    <dd><?php echo e($book->user->name); ?></dd>
    <dt>感想文</dt>
    <dd><?php echo nl2br(e($book->review)); ?></dd>
</dl>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/books/show.blade.php ENDPATH**/ ?>