@extends('layouts.app')

@section('content')
<h1>みんなの蔵書</h1>
@include('commons.books')
@endsection
