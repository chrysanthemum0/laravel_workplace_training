<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'category_id', 'price', 'description'];

    public function Category()
    {
        return $this->belongsTo(Category::class);
        //product는 반드시 1개의 category에 속하기 때문에 관계정의
    }
}
