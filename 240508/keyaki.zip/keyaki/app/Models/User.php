<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function books(){
        return $this->hasMany(Book::class);
        //Book모델과 1대다 정의
    }

    public function likebooks(){
        return $this->belongsToMany(Book::class, 'likes')->withTimestamps();
        //belongsToMany() 다대다 관계 정의 -> 제1인수에 중간테이블을 통해 취득
        //withTimestamps() likes 테이블의 2개의 타임스탬프가 자동적으로 갱신
    }

    public function isLike($book_id){
        return $this->likebooks()->where('books.id', $book_id)->exists();
    }
}
