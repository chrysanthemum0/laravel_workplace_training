<?php $__env->startSection('content'); ?>
<h1>書籍情報編集</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('books.update', $book->id)); ?>" method="post" >
    <?php echo method_field('patch'); ?>
    <?php echo $__env->make('books.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="submit">更新</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/books/edit.blade.php ENDPATH**/ ?>