<?php if(Auth::check()): ?>
    <ul class="navigation">
        <li>
            <a href="<?php echo e(route('home')); ?>">マイページ</a>
        </li>
        <li>
            <a href="<?php echo e(route('books.index')); ?>">みんなの書籍</a>
        </li>
        <li>
            <a href="#" onclick="logout()">ログアウト</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post" >
                <?php echo csrf_field(); ?>
            </form>
            <script type="text/javascript">
                function logout() {
                    event.preventDefault();
                    if(window.confirm('ログアウトしますか？')){
                        document.getElementById('logout-form').submit();
                    }
                }
            </script>
        </li>
    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/commons/nav.blade.php ENDPATH**/ ?>