<?php echo csrf_field(); ?>
<dl>
    <dt>タイトル（必須）</dt>
    <dd>
        <input type="text" name="title" value="<?php echo e(old('title', $book->title)); ?>">
    </dd>
    <dt>著者</dt>
    <dd>
        <input type="text" name="author" value="<?php echo e(old('author', $book->author)); ?>">
    </dd>
    <dt>出版社</dt>
    <dd>
        <input type="text" name="publisher" value="<?php echo e(old('publisher', $book->publisher)); ?>">
    </dd>
    <dt>感想文</dt>
    <dd>
        <textarea name="review" rows="5">
            <?php echo e(old('review', $book->review)); ?></textarea>
    </dd>
</dl>
<?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/books/form.blade.php ENDPATH**/ ?>