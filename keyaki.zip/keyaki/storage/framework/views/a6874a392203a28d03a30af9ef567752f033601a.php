<table class="table">
    <thead>
        <tr>
            <th>投稿者</th>
            <th>タイトル</th>
            <th>著者</th>
            <th>出版社</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->user->name); ?></td>
                <td>
                    <a href="<?php echo e(route('books.show', $book->id)); ?>">
                        <?php echo e($book->title); ?>

                    </a>
                </td>
                <td><?php echo e($book->author); ?></td>
                <td><?php echo e($book->publisher); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($books->links()); ?>

<?php /**PATH C:\Users\student\Desktop\laravel\keyaki\resources\views/commons/books.blade.php ENDPATH**/ ?>