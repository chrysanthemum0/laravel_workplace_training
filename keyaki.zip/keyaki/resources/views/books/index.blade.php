@extends('layouts.app')

@section('content')
<h1>みんなの書籍</h1>
@include('commons.books')

@endsection
